﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex11
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.Write("Введите Вашe имя: ");
            string name = (Console.ReadLine());

            Console.Write("Введите Вашу фамилию: ");
            string surname = (Console.ReadLine());

            Console.Write("Введите Ваш возраст: ");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите Ваш рост: ");
            uint height = Convert.ToUInt32(Console.ReadLine());

            Console.Write("Введите Ваш вес: ");
            uint weight = Convert.ToUInt32(Console.ReadLine());

            //а) используя склеивание;
            //Console.WriteLine("Имя: "+name+", Фамилия: "+surname+", Возраст: "+age.ToString()+", Рост: "+height.ToString()+", Вес: "+weight.ToString());

            //б) используя форматированный вывод;

            //string text = String.Format("Имя: {0}, Фамилия: {1}, Возраст: {2}, Рост: {3}, Вес: {4}",
            //        name,
            //        surname,
            //        age,
            //        height,
            //        weight);
            //Console.WriteLine(text);

            //в) используя вывод со знаком $;

            string text = String.Format($"Имя: {name}, Фамилия: {surname}, Возраст: {age}, Рост: {height}, Вес: {weight}");

            Console.WriteLine(text);
            Console.ReadLine();
                


        }
    }
}
