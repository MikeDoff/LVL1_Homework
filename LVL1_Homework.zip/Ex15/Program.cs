﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите Вашe имя: ");
            string fName = (Console.ReadLine());

            Console.Write("Введите Вашу фамилию: ");
            string lName = (Console.ReadLine());

            Console.Write("Введите город проживания: ");
            string res = (Console.ReadLine());

            string pData = $"{fName} {lName} {res}";

            Console.WriteLine(pData);      


            Console.Clear();

            Console.SetCursorPosition(Console.WindowWidth / 2 - txt.length/2, Console.WindowHeight / 2);
            Console.WriteLine(pData);
            Console.ReadLine();
        }
    }
}
