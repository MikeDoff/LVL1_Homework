﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите координату х1: ");
            double x1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Введите координату y1: ");
            double y1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Введите координату x2: ");
            double x2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Введите координату y2: ");
            double y2 = Convert.ToDouble(Console.ReadLine());

            double r = Distance(x1, y1, x2, y2);

            Console.WriteLine($"Расстояние между точками координат: {r.ToString("#.##")}");
            Console.ReadLine();
        }

        private static double Distance(double x1, double y1, double x2, double y2)
        {
            return Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
        }
    }
}
